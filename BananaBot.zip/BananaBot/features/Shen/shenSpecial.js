const itemRotation = [
    "Priceless The Fish",
    "Clover Helmet",
    "Giant Fishing Rod",
    "Racing Helmet",
    "Dirt Rod",
    "Wizard Wand"
]

currentItem = "Dirt Rod"